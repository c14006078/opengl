/*
 * Nehe Lesson 36 Code (ported to Linux//GLX by Patrick Schubert 2003
 * with help from the lesson 1 basecode for Linux/GLX by Mihael Vrbanec)
 */

#ifndef NEHE_BASE_H
#define NEHE_BASE_H

void createGLWindow(const char*,int,int,int,int);
void killGLWindow(void);
void run(void);
void getScreenSize(unsigned int*,unsigned int*);

#endif
