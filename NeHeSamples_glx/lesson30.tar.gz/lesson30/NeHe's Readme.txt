OpenGL Tutorial #30.

Project Name: Collision Detection Tutorial.

Project Description:  Features Collision Detection, Collision Response,
                      And Physically Based Modeling and Effects.

Authors Name: Dimi Christopoulos

Authors Web Site: nehe.gamedev.net

COPYRIGHT AND DISCLAIMER: (c)2000 Jeff Molofee

	If you plan to put this program on your web page or a cdrom of
	any sort, let me know via email, I'm curious to see where
	it ends up :)
